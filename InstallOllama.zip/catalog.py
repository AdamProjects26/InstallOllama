"""Ollama model catalog — 100 models with categories and approximate disk sizes."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Model:
    name: str  # display name
    tag: str  # `ollama pull <tag>`
    category: str
    size_gb: float  # approximate download size
    desc: str


CATEGORIES = ["All", "Lightweight", "General", "Code", "Reasoning", "Vision", "Large", "Safety"]

MODELS: list[Model] = [
    # ---------------------------------------------------------------- lightweight
    Model("SmolLM2 (135M)", "smollm2:135m", "Lightweight", 0.1, "Tiny & instant"),
    Model("SmolLM2 (360M)", "smollm2:360m", "Lightweight", 0.3, "Ultra-compact"),
    Model("Qwen 2.5 (0.5B)", "qwen2.5:0.5b", "Lightweight", 0.4, "Multilingual micro model"),
    Model("Qwen 3 (0.6B)", "qwen3:0.6b", "Lightweight", 0.5, "Qwen micro model"),
    Model("TinyLlama (1.1B)", "tinyllama", "Lightweight", 0.6, "Classic tiny assistant"),
    Model("Gemma 3 (1B)", "gemma3:1b", "Lightweight", 0.8, "Google micro model"),
    Model("Qwen 2.5 (1.5B)", "qwen2.5:1.5b", "Lightweight", 1.0, "Multilingual, small"),
    Model("DeepSeek R1 (1.5B)", "deepseek-r1:1.5b", "Reasoning", 1.1, "Distilled reasoning"),
    Model("SmolLM2 (1.7B)", "smollm2:1.7b", "Lightweight", 1.2, "HuggingFace small LM"),
    Model("Qwen 3 (1.7B)", "qwen3:1.7b", "Lightweight", 1.4, "Fast hybrid thinker"),
    Model("Gemma 2 (2B)", "gemma2:2b", "Lightweight", 1.6, "Google lightweight"),
    Model("CodeGemma (2B)", "codegemma", "Code", 1.6, "Google code micro"),
    Model("Moondream (2B)", "moondream", "Vision", 1.7, "Fast vision model"),
    Model("Gemma (2B)", "gemma", "Lightweight", 1.7, "First-gen Gemma"),
    Model("Phi 3 Mini (3.8B)", "phi3", "Lightweight", 2.2, "Lightweight & fast"),
    Model("Phi 4 Mini (3.8B)", "phi4-mini", "Lightweight", 2.5, "Newer Phi micro"),
    Model("LLaVA Phi 3 (3.8B)", "llava-phi3", "Vision", 2.2, "Compact vision LLaVA"),
    Model("StableLM Zephyr (3B)", "stablelm-zephyr-3b", "Lightweight", 1.9, "Stability AI chat"),
    Model("Qwen 2.5 (3B)", "qwen2.5:3b", "Lightweight", 1.9, "Multilingual small"),
    Model("StarCoder2 (3B)", "starcoder2:3b", "Code", 1.9, "BigCode small coder"),
    Model("Qwen 2.5 Coder (0.5B)", "qwen2.5-coder:0.5b", "Code", 0.4, "Micro coder"),
    Model("Qwen 2.5 Coder (1.5B)", "qwen2.5-coder:1.5b", "Code", 1.0, "Small coder"),
    Model("Qwen 2.5 Coder (3B)", "qwen2.5-coder:3b", "Code", 1.9, "Compact coder"),
    Model("Gemma 3n (E2B)", "gemma3n:e2b", "Lightweight", 2.9, "Mobile-first"),
    Model("Qwen 3 (4B)", "qwen3:4b", "Lightweight", 2.6, "Hybrid reasoning micro"),
    Model("Llama 3.2 (1B)", "llama3.2:1b", "Lightweight", 1.3, "Meta micro model"),
    Model("Llama 3.2 (3B)", "llama3.2:3b", "Lightweight", 2.0, "Meta compact model"),
    Model("Granite 3.0 (2B)", "granite3.0:2b", "Lightweight", 2.7, "IBM enterprise micro"),
    Model("Gemma 3 (4B)", "gemma3:4b", "General", 3.3, "Balanced Google model"),
    Model("Phi 4 Multimodal (5.6B)", "phi4-multimodal", "Vision", 3.4, "Vision + audio + text"),
    Model("Gemma 3n (E4B)", "gemma3n:e4b", "Lightweight", 4.4, "Mobile-first, larger"),
    # ---------------------------------------------------------------- general
    Model("Llama 2 (7B)", "llama2", "General", 3.8, "Previous-gen Meta"),
    Model("Vicuna (7B)", "vicuna", "General", 3.9, "Fine-tuned LLaMA chat"),
    Model("OpenChat (7B)", "openchat", "General", 4.1, "Community fine-tune"),
    Model("Neural Chat (7B)", "neural-chat", "General", 4.1, "Intel tuned chat"),
    Model("Mistral (7B)", "mistral", "General", 4.1, "High quality small model"),
    Model("Falcon (7B)", "falcon", "General", 4.5, "TII foundation model"),
    Model("Llama 3 (8B)", "llama3", "General", 4.7, "General purpose workhorse"),
    Model("Llama 3.1 (8B)", "llama3.1:8b", "General", 4.7, "128K context Llama"),
    Model("Qwen 2.5 (7B)", "qwen2.5:7b", "General", 4.7, "Strong multilingual"),
    Model("Qwen 3 (8B)", "qwen3:8b", "General", 5.2, "Hybrid reasoning"),
    Model("Llama 3.2 Vision (11B)", "llama3.2-vision:11b", "Vision", 7.9, "Meta image understanding"),
    Model("Gemma 2 (9B)", "gemma2:9b", "General", 5.4, "Google mid-size"),
    Model("Granite 3.0 (8B)", "granite3.0:8b", "General", 4.9, "IBM enterprise"),
    Model("Mistral Nemo (12B)", "mistral-nemo", "General", 7.1, "NVIDIA collab, 128K ctx"),
    Model("Gemma 3 (12B)", "gemma3:12b", "General", 8.1, "Multimodal Google"),
    Model("Vicuna (13B)", "vicuna:13b", "General", 7.4, "Classic chat fine-tune"),
    Model("Llama 2 (13B)", "llama2:13b", "General", 7.4, "Previous-gen, larger"),
    Model("Falcon 2 (11B)", "falcon2", "General", 7.5, "TII multilingual"),
    Model("Phi 3 Medium (14B)", "phi3:14b", "General", 7.9, "Microsoft mid-size"),
    Model("Phi 4 (14B)", "phi4", "General", 9.1, "Excellent reasoning per GB"),
    Model("Qwen 2.5 (14B)", "qwen2.5:14b", "General", 9.0, "Strong multilingual"),
    Model("Qwen 3 (14B)", "qwen3:14b", "General", 9.3, "Hybrid thinking"),
    Model("Solar Pro (22B)", "solar-pro", "General", 14, "Upstage depth-upscale"),
    Model("Mistral Small 3 (24B)", "mistral-small3.1", "General", 14, "New Mistral flagship-small"),
    Model("Gemma 2 (27B)", "gemma2:27b", "General", 16, "Google quality"),
    Model("Gemma 3 (27B)", "gemma3:27b", "General", 17, "Multimodal, long context"),
    Model("Qwen 3 (30B-A3B)", "qwen3:30b-a3b", "Reasoning", 19, "MoE, fast per token"),
    Model("Qwen 2.5 (32B)", "qwen2.5:32b", "General", 20, "Near-frontier quality"),
    Model("Qwen 3 (32B)", "qwen3:32b", "General", 20, "Flagship dense model"),
    Model("Falcon (40B)", "falcon:40b", "Large", 23, "Large TII model"),
    Model("Mixtral (8x7B)", "mixtral:8x7b", "General", 26, "Sparse MoE"),
    # ---------------------------------------------------------------- code
    Model("CodeGemma (7B)", "codegemma:7b", "Code", 5.0, "Google code model"),
    Model("StarCoder2 (7B)", "starcoder2:7b", "Code", 4.2, "BigCode coder"),
    Model("CodeLLaMA (7B)", "codellama", "Code", 3.8, "Specialized for coding"),
    Model("CodeLLaMA Python (7B)", "codellama:python", "Code", 3.8, "Python specialist"),
    Model("WizardCoder (7B)", "wizardcoder", "Code", 4.1, "CodeLlama fine-tune"),
    Model("CodeQwen (7B)", "codeqwen", "Code", 4.7, "Qwen code expert"),
    Model("Granite Code (8B)", "granite-code", "Code", 4.7, "IBM code model"),
    Model("CodeLLaMA (13B)", "codellama:13b", "Code", 7.4, "Larger coder"),
    Model("DeepSeek Coder V2 (16B)", "deepseek-coder-v2:16b", "Code", 8.9, "MoE coding expert"),
    Model("Qwen 2.5 Coder (7B)", "qwen2.5-coder:7b", "Code", 4.7, "Balanced coder"),
    Model("Qwen 2.5 Coder (14B)", "qwen2.5-coder:14b", "Code", 9.0, "Strong coder"),
    Model("StarCoder2 (15B)", "starcoder2:15b", "Code", 9.3, "BigCode large"),
    Model("Codestral (22B)", "codestral", "Code", 13, "Mistral code expert"),
    Model("Qwen 2.5 Coder (32B)", "qwen2.5-coder:32b", "Code", 20, "Near-frontier coder"),
    Model("Qwen 3 Coder (30B)", "qwen3-coder:30b", "Code", 19, "Agentic coding MoE"),
    Model("CodeLLaMA (34B)", "codellama:34b", "Code", 19, "Large coder"),
    # ---------------------------------------------------------------- reasoning
    Model("WizardMath (7B)", "wizard-math", "Reasoning", 4.1, "Math specialist"),
    Model("DeepSeek R1 (7B)", "deepseek-r1:7b", "Reasoning", 4.7, "Distilled reasoning"),
    Model("DeepSeek R1 (8B)", "deepseek-r1:8b", "Reasoning", 5.2, "Distilled reasoning"),
    Model("DeepSeek R1 (14B)", "deepseek-r1:14b", "Reasoning", 9.0, "Strong chain-of-thought"),
    Model("DeepSeek R1 (32B)", "deepseek-r1:32b", "Reasoning", 20, "Heavy reasoning"),
    Model("DeepSeek R1 (70B)", "deepseek-r1:70b", "Large", 47, "Frontier-class reasoning"),
    Model("DeepSeek R1 (671B)", "deepseek-r1:671b", "Large", 404, "Full MoE — extreme!"),
    # ---------------------------------------------------------------- vision
    Model("LLaVA (7B)", "llava", "Vision", 4.5, "Open vision assistant"),
    Model("BakLLaVA (7B)", "bakllava", "Vision", 4.2, "LLaVA 1.5 pipeline"),
    Model("LLaVA Llama 3 (8B)", "llava-llama3", "Vision", 5.5, "Llama-3 vision"),
    Model("MiniCPM-V 2.6 (8B)", "minicpm-v:2.6", "Vision", 5.5, "Strong mobile vision"),
    Model("MiniCPM-V (8B)", "minicpm-v", "Vision", 7.6, "Open vision model"),
    # ---------------------------------------------------------------- large
    Model("Llama 2 (70B)", "llama2:70b", "Large", 39, "Previous-gen flagship"),
    Model("Llama 3.1 (70B)", "llama3.1:70b", "Large", 40, "128K context flagship"),
    Model("Llama 3.3 (70B)", "llama3.3:70b", "Large", 43, "Best open Llama chat"),
    Model("Qwen 2.5 (72B)", "qwen2.5:72b", "Large", 47, "Multilingual flagship"),
    Model("Llama 3.2 Vision (90B)", "llama3.2-vision:90b", "Vision", 54, "Meta vision flagship"),
    Model("OpenAI GPT-OSS (20B)", "openai/gpt-oss:20b", "Reasoning", 13, "Open-weight o-series"),
    Model("OpenAI GPT-OSS (120B)", "openai/gpt-oss:120b", "Large", 65, "Open-weight reasoning"),
    Model("Mixtral (8x22B)", "mixtral:8x22b", "Large", 87, "Large sparse MoE"),
    Model("Qwen 3 (235B-A22B)", "qwen3:235b-a22b", "Large", 142, "MoE frontier model"),
    # ---------------------------------------------------------------- safety
    Model("Llama Guard 3 (8B)", "llama-guard3", "Safety", 4.8, "Content safety classifier"),
    Model("Llama Guard 4 (12B)", "llama-guard4", "Safety", 7.0, "Newer safety classifier"),
]


def fmt_size(gb: float) -> str:
    if gb >= 1024:
        return f"{gb / 1024:.1f} TB"
    if gb >= 1:
        return f"{gb:.1f} GB"
    return f"{int(gb * 1024)} MB"


def free_disk_gb() -> float:
    import os
    import shutil

    try:
        return shutil.disk_usage(os.path.expanduser("~")).free / (1024**3)
    except OSError:
        return 0.0
