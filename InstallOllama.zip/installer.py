"""Background installation engine for InstallOllama.

Runs every system command on a worker thread, streams stdout/stderr in
real-time, and reports progress back to the GUI through a callback:

    progress_cb(message: str, percent: float | None, phase: str)

Phases: "install" | "service" | "models" | "done" | "error" | "cancelled"
`percent` is None for terminal (done/error/cancelled) states.
"""

from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import threading
from dataclasses import dataclass
from typing import Callable, Optional

SYSTEM = platform.system()

PERCENT_RE = re.compile(r"(\d{1,3}(?:\.\d+)?)%")

ProgressCallback = Callable[[str, Optional[float], str], None]


@dataclass
class InstallConfig:
    version: str  # "Latest Stable" or "Pre-release"
    models: list[tuple[str, str]]  # (tag, display name), e.g. [("llama3", "Llama 3 (8B)")]


class Installer:
    """Coordinates the Ollama install + model pulls.

    The progress callback is invoked from the worker thread; the GUI
    marshals it onto the Tk main loop with `widget.after(...)`.
    """

    # Progress budget: install 0-55%, service 55-60%, models 60-100%.
    INSTALL_SPAN = 55.0
    SERVICE_PCT = 60.0
    MODELS_BASE = 60.0
    MODELS_SPAN = 40.0

    def __init__(self, config: InstallConfig, progress_cb: ProgressCallback):
        self.config = config
        self._cb = progress_cb
        self._cancel = threading.Event()
        self._process: Optional[subprocess.Popen] = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ utils

    def cancel(self) -> None:
        self._cancel.set()
        with self._lock:
            proc = self._process
        if proc and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass

    def _report(self, message: str, percent: Optional[float], phase: str = "models") -> None:
        if not self._cancel.is_set():
            self._cb(message, percent, phase)

    def _run_streaming(
        self,
        cmd: list[str],
        base_status: str,
        base_percent: float = 0.0,
        span: float = 10.0,
        phase: str = "install",
        timeout: Optional[int] = None,
    ) -> None:
        """Spawn a process, stream its output line by line, parse percentages."""
        creationflags = 0
        if SYSTEM == "Windows":
            # Hide the console window; keep a real pipe so we can read output.
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

        self._report(base_status, base_percent, phase)

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            creationflags=creationflags,
        )
        with self._lock:
            self._process = proc

        last_percent = base_percent
        try:
            assert proc.stdout is not None
            for raw in proc.stdout:
                if self._cancel.is_set():
                    proc.terminate()
                    raise InterruptedError("Installation cancelled by user")

                line = raw.strip()
                if not line:
                    continue

                match = PERCENT_RE.search(line)
                if match:
                    pct = min(100.0, float(match.group(1)))
                    last_percent = base_percent + (pct / 100.0) * span
                    self._report(f"{base_status} — {line}", last_percent, phase)
                else:
                    self._report(f"{base_status} — {line}", last_percent, phase)

            returncode = proc.wait(timeout=timeout)
        finally:
            with self._lock:
                self._process = None

        if self._cancel.is_set():
            raise InterruptedError("Installation cancelled by user")
        if returncode != 0:
            raise RuntimeError(f"Command failed (exit {returncode}): {' '.join(cmd)}")

    # -------------------------------------------------------- install steps

    def ollama_installed(self) -> bool:
        return shutil.which("ollama") is not None

    def start_service(self) -> None:
        """Make sure the `ollama serve` process is running."""
        if self.ollama_installed():
            try:
                import urllib.request

                urllib.request.urlopen("http://127.0.0.1:11434", timeout=2)
                return  # already up
            except Exception:
                pass

        creationflags = 0
        if SYSTEM == "Windows":
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )

    def _install_windows(self) -> None:
        self._run_streaming(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                "irm https://ollama.com/install.ps1 | iex",
            ],
            base_status="Downloading & installing Ollama",
            base_percent=0.0,
            span=self.INSTALL_SPAN,
            phase="install",
            timeout=900,
        )

    def _install_unix(self) -> None:
        import tempfile

        script_path = os.path.join(tempfile.gettempdir(), "ollama-install.sh")
        self._report("Downloading installer script...", 5.0, "install")
        download = subprocess.run(
            ["curl", "-fsSL", "-o", script_path, "https://ollama.com/install.sh"],
            capture_output=True,
            text=True,
        )
        if download.returncode != 0:
            raise RuntimeError(f"Failed to download installer: {download.stderr.strip()}")
        self._run_streaming(
            ["sh", script_path],
            base_status="Installing Ollama",
            base_percent=10.0,
            span=self.INSTALL_SPAN - 10.0,
            phase="install",
            timeout=900,
        )

    def _install(self) -> None:
        if self.ollama_installed() and self.config.version == "Latest Stable":
            self._report("Ollama is already installed — checking for updates...", 50.0, "install")
            return

        if SYSTEM == "Windows":
            self._install_windows()
        else:
            self._install_unix()

    def _pull_model(self, tag: str, display: str, index: int, total: int) -> None:
        share = self.MODELS_SPAN / max(total, 1)
        base = self.MODELS_BASE + index * share
        self._report(f"Pulling {display} ({tag})...", base, "models")
        self._run_streaming(
            ["ollama", "pull", tag],
            base_status=f"Pulling {display}",
            base_percent=base,
            span=share,
            phase="models",
            timeout=7200,
        )

    # ------------------------------------------------------------------ main

    def run(self) -> None:
        try:
            self._install()
            if self._cancel.is_set():
                raise InterruptedError("Installation cancelled by user")

            self._report("Starting Ollama service...", self.SERVICE_PCT, "service")
            self.start_service()

            models = self.config.models
            total = len(models)
            for i, (tag, display) in enumerate(models):
                if self._cancel.is_set():
                    raise InterruptedError("Installation cancelled by user")
                self._report(
                    f"Model {i + 1}/{total}: {display}",
                    self.MODELS_BASE + (i / max(total, 1)) * self.MODELS_SPAN,
                    "models",
                )
                self._pull_model(tag, display, i, total)

            self._report("Installation complete!", 100.0, "done")
        except InterruptedError:
            self._cb("Installation cancelled.", None, "cancelled")
        except Exception as exc:  # surface any failure to the UI
            self._cb(f"Error: {exc}", None, "error")

    def start(self) -> threading.Thread:
        thread = threading.Thread(target=self.run, daemon=True)
        thread.start()
        return thread


def elevated_shell_hint() -> str:
    if SYSTEM == "Windows":
        return "Run as Administrator for a smooth install."
    return "You may be prompted for your sudo password during install."
