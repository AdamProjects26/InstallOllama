# InstallOllama

A modern, dark-themed, cross-platform desktop app that visually installs
[Ollama](https://ollama.com) and pulls selected models — no terminal required.

Built with Python + `customtkinter`. Runs every system command on a
**background thread**, streams terminal output in real time, parses download
percentages, and updates the progress bar safely (via Tk's `after()`).

## Screens / State machine

1. **Welcome** — split-color "Install**Ollama**" title, feature cards
   (1-Click Install · 101 Models · Live Progress), and a "Get started" button.
2. **Configuration**
   - Version dropdown (Latest Stable / Pre-release) + live free-disk readout.
   - **Search box** (name/tag/description) and **category filter**
     (Lightweight, General, Code, Reasoning, Vision, Large, Safety).
   - Scrollable list of **101 models** — each row shows name, Ollama tag,
     short description, and a color-coded size badge (green < 5 GB,
     amber < 20 GB, red ≥ 20 GB).
   - Select All / None for the current filter.
   - Live footer: `N models selected · X.X GB download`, turning red with a
     warning if the total exceeds free disk space.
3. **Installation & Progress** — phase stepper
   (Install Ollama → Start Service → Pull Models), live status line, overall
   progress bar with percentage, and a scrolling terminal-style log.
   Cancel and Done controls included.

## Requirements

- Python 3.9+
- Internet connection
- **Windows:** run as Administrator (recommended). The official
  `install.ps1` script is invoked for you.
- **macOS / Linux:** you may be prompted for your `sudo` password; the official
  `install.sh` script is downloaded and executed.

## Install & Run

```bash
pip install -r requirements.txt
python main.py
```

## Project layout

```
InstallOllama/
├── main.py               # GUI: customtkinter app + 3-state flow
├── installer.py          # Background engine: streams commands, parses %, phases
├── catalog.py            # 101-model catalog with categories & size estimates
├── emerald_theme.json    # Custom dark + emerald theme (CTK 5.x & 6.x)
├── requirements.txt
└── README.md
```

## How it works

- **Windows:** runs `irm https://ollama.com/install.ps1 | iex` in a hidden
  PowerShell process (`CREATE_NO_WINDOW` so no console flashes).
- **macOS / Linux:** downloads `https://ollama.com/install.sh` to a temp file,
  then runs it with `sh`.
- Starts the `ollama serve` service, then runs `ollama pull <tag>` for each
  checked model sequentially.
- Each process's stdout is read line-by-line on a worker thread; regex-extracted
  percentages map into slices of the overall progress bar
  (install 0–55%, service 55–60%, models 60–100%).
- Cancel terminates the active process; errors are shown in red with the
  Done button enabled.

> Note: model sizes are approximate (default tag, disk footprint after pull).
> "Pre-release" currently follows the same official install channel — Ollama
> does not publish a separate public pre-release installer; the option is kept
> for forward-compatibility.
