"""InstallOllama — a modern, cross-platform visual installer for Ollama.

States: Welcome -> Configuration -> Installation Progress.
All system commands run on a background thread; the GUI is updated safely
via `after()` so the window never freezes.
"""

from __future__ import annotations

import os
from typing import Optional

import customtkinter as ctk

from catalog import CATEGORIES, MODELS, Model, fmt_size, free_disk_gb
from installer import InstallConfig, Installer, elevated_shell_hint

# ---------------------------------------------------------------- appearance

_HERE = os.path.dirname(os.path.abspath(__file__))

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme(os.path.join(_HERE, "emerald_theme.json"))

ACCENT = "#10b981"
ACCENT_DIM = "#059669"
ACCENT_BG = "#0d2521"  # accent blended ~13% over BG
ACCENT_BG2 = "#0d3129"  # accent blended ~20% over BG
BG = "#0d0f12"
SURFACE = "#161a20"
SURFACE_2 = "#1d232b"
TEXT = "#f3f4f6"
MUTED = "#8b95a5"
AMBER = "#f59e0b"
RED = "#ef4444"

WINDOW_W, WINDOW_H = 760, 640

PHASE_STEPS = ["Install Ollama", "Start Service", "Pull Models"]


def size_color(gb: float) -> str:
    if gb < 5:
        return ACCENT
    if gb < 20:
        return AMBER
    return RED


class InstallOllamaApp(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title("InstallOllama")
        self.resizable(False, False)
        self.configure(fg_color=BG)
        self._center_window()

        self._installer: Optional[Installer] = None
        self._last_logged = ""

        self._container = ctk.CTkFrame(self, fg_color=BG)
        self._container.pack(fill="both", expand=True)

        self.frames: dict[str, ctk.CTkFrame] = {}
        self.frames["welcome"] = self._build_welcome()
        self.frames["config"] = self._build_config()
        self.frames["progress"] = self._build_progress()

        self.show("welcome")

    # ---------------------------------------------------------------- helpers

    def _center_window(self) -> None:
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        x, y = (sw - WINDOW_W) // 2, (sh - WINDOW_H) // 2
        self.geometry(f"{WINDOW_W}x{WINDOW_H}+{x}+{y}")

    def show(self, name: str) -> None:
        for frame in self.frames.values():
            frame.pack_forget()
        self.frames[name].pack(fill="both", expand=True)
        if name == "config":
            self._refresh_model_list()
            self._update_stats()

    def _card(self, parent, **kw) -> ctk.CTkFrame:
        defaults = dict(
            fg_color=SURFACE,
            corner_radius=16,
            border_width=1,
            border_color="#232a33",
        )
        defaults.update(kw)
        return ctk.CTkFrame(parent, **defaults)

    # ----------------------------------------------------------- state 1 UI

    def _build_welcome(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self._container, fg_color=BG)
        frame.grid_columnconfigure(0, weight=1)

        badge = ctk.CTkLabel(
            frame,
            text="  MODERN OLLAMA INSTALLER  ",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=ACCENT,
            fg_color=ACCENT_BG,
            corner_radius=20,
            padx=6,
        )
        badge.grid(row=0, column=0, pady=(56, 18))

        title = ctk.CTkLabel(
            frame,
            text="Install",
            font=ctk.CTkFont(family="Segoe UI", size=52, weight="bold"),
            text_color=TEXT,
        )
        title.grid(row=1, column=0)

        title2 = ctk.CTkLabel(
            frame,
            text="Ollama",
            font=ctk.CTkFont(family="Segoe UI", size=52, weight="bold"),
            text_color=ACCENT,
        )
        title2.grid(row=2, column=0, pady=(0, 10))

        subtitle = ctk.CTkLabel(
            frame,
            text="Install Ollama and 100+ AI models in one click — no terminal needed.",
            font=ctk.CTkFont(size=14),
            text_color=MUTED,
        )
        subtitle.grid(row=3, column=0, padx=40, pady=(0, 30))

        # Feature cards
        cards_wrap = ctk.CTkFrame(frame, fg_color="transparent")
        cards_wrap.grid(row=4, column=0, pady=(0, 36))
        for i, (icon, head, sub) in enumerate(
            [
                ("⚡", "1-Click Install", "Official Ollama installer"),
                ("◆", "100+ Models", "With size estimates"),
                ("◉", "Live Progress", "Real-time download %"),
            ]
        ):
            card = self._card(cards_wrap, width=190, height=96, corner_radius=14)
            card.grid(row=0, column=i, padx=8)
            card.grid_propagate(False)
            ctk.CTkLabel(
                card, text=icon, font=ctk.CTkFont(size=20), text_color=ACCENT
            ).grid(row=0, column=0, pady=(12, 0))
            ctk.CTkLabel(
                card, text=head, font=ctk.CTkFont(size=13, weight="bold"), text_color=TEXT
            ).grid(row=1, column=0)
            ctk.CTkLabel(
                card, text=sub, font=ctk.CTkFont(size=11), text_color=MUTED
            ).grid(row=2, column=0, pady=(2, 0))

        start_btn = ctk.CTkButton(
            frame,
            text="Get started  →",
            width=240,
            height=52,
            corner_radius=26,
            font=ctk.CTkFont(size=16, weight="bold"),
            fg_color=ACCENT,
            hover_color=ACCENT_DIM,
            command=lambda: self.show("config"),
        )
        start_btn.grid(row=5, column=0, pady=(0, 18))

        hint = ctk.CTkLabel(
            frame,
            text=elevated_shell_hint(),
            font=ctk.CTkFont(size=11),
            text_color=MUTED,
        )
        hint.grid(row=6, column=0, pady=(0, 16))

        return frame

    # ----------------------------------------------------------- state 2 UI

    def _build_config(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self._container, fg_color=BG)
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(4, weight=1)  # model list expands

        # --- top bar: compact title + back
        top = ctk.CTkFrame(frame, fg_color="transparent")
        top.grid(row=0, column=0, sticky="ew", padx=28, pady=(14, 8))
        top.grid_columnconfigure(1, weight=1)

        back = ctk.CTkButton(
            top,
            text="←",
            width=36,
            height=32,
            corner_radius=10,
            fg_color=SURFACE,
            hover_color=SURFACE_2,
            text_color=MUTED,
            font=ctk.CTkFont(size=14, weight="bold"),
            command=lambda: self.show("welcome"),
        )
        back.grid(row=0, column=0, sticky="w")

        ctk.CTkLabel(
            top,
            text="Configuration",
            font=ctk.CTkFont(family="Segoe UI", size=24, weight="bold"),
            text_color=TEXT,
        ).grid(row=0, column=1, sticky="w", padx=14)

        self.disk_label = ctk.CTkLabel(
            top,
            text="",
            font=ctk.CTkFont(size=12),
            text_color=MUTED,
        )
        self.disk_label.grid(row=0, column=2, sticky="e")

        # --- version row
        ver_card = self._card(frame)
        ver_card.grid(row=1, column=0, sticky="ew", padx=28, pady=(4, 8))
        ver_card.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            ver_card,
            text="Ollama version",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=TEXT,
        ).grid(row=0, column=0, sticky="w", padx=18, pady=14)

        self.version_var = ctk.StringVar(value="Latest Stable")
        ctk.CTkOptionMenu(
            ver_card,
            variable=self.version_var,
            values=["Latest Stable", "Pre-release"],
            width=220,
            fg_color=SURFACE_2,
            button_color=ACCENT,
            button_hover_color=ACCENT_DIM,
            corner_radius=10,
        ).grid(row=0, column=1, sticky="e", padx=14, pady=10)

        # --- filter row
        filter_card = self._card(frame)
        filter_card.grid(row=2, column=0, sticky="ew", padx=28, pady=(0, 8))
        filter_card.grid_columnconfigure(0, weight=1)

        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._refresh_model_list())
        search = ctk.CTkEntry(
            filter_card,
            textvariable=self.search_var,
            placeholder_text="Search models…  (name, tag, description)",
            height=38,
            corner_radius=10,
            fg_color=SURFACE_2,
            border_color="#2a323d",
            text_color=TEXT,
            placeholder_text_color=MUTED,
        )
        search.grid(row=0, column=0, sticky="ew", padx=12, pady=(12, 4))

        self.category_var = ctk.StringVar(value="All")
        self.category_var.trace_add("write", lambda *_: self._refresh_model_list())
        cat = ctk.CTkOptionMenu(
            filter_card,
            variable=self.category_var,
            values=CATEGORIES,
            width=140,
            height=38,
            corner_radius=10,
            fg_color=SURFACE_2,
            button_color=ACCENT,
            button_hover_color=ACCENT_DIM,
        )
        cat.grid(row=0, column=1, padx=(8, 4), pady=(12, 4))

        btns = ctk.CTkFrame(filter_card, fg_color="transparent")
        btns.grid(row=0, column=2, padx=(0, 8), pady=(12, 4))
        ctk.CTkButton(
            btns,
            text="All",
            width=44,
            height=30,
            corner_radius=8,
            fg_color=SURFACE_2,
            hover_color="#2a323d",
            text_color=MUTED,
            font=ctk.CTkFont(size=11, weight="bold"),
            command=self._select_all,
        ).grid(row=0, column=0, padx=(0, 4))
        ctk.CTkButton(
            btns,
            text="None",
            width=52,
            height=30,
            corner_radius=8,
            fg_color=SURFACE_2,
            hover_color="#2a323d",
            text_color=MUTED,
            font=ctk.CTkFont(size=11, weight="bold"),
            command=self._select_none,
        ).grid(row=0, column=1)

        self.count_label = ctk.CTkLabel(
            filter_card,
            text="",
            font=ctk.CTkFont(size=11),
            text_color=MUTED,
            anchor="w",
        )
        self.count_label.grid(row=1, column=0, columnspan=3, sticky="w", padx=14, pady=(0, 10))

        # --- model list
        list_card = self._card(frame, corner_radius=16)
        list_card.grid(row=4, column=0, sticky="nsew", padx=28, pady=(0, 8))
        list_card.grid_columnconfigure(0, weight=1)
        list_card.grid_rowconfigure(0, weight=1)

        self.model_list = ctk.CTkScrollableFrame(
            list_card,
            fg_color="transparent",
            corner_radius=12,
        )
        self.model_list.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        self.model_list.grid_columnconfigure(0, weight=1)

        # model rows live here: tag -> widgets
        self.model_vars: dict[str, ctk.BooleanVar] = {}
        self.row_widgets: dict[str, tuple] = {}

        for m in MODELS:
            var = ctk.BooleanVar(value=False)
            self.model_vars[m.tag] = var
            row = self._make_model_row(self.model_list, m, var)
            self.row_widgets[m.tag] = row

        # --- footer: stats + install
        footer = ctk.CTkFrame(frame, fg_color="transparent")
        footer.grid(row=5, column=0, sticky="ew", padx=28, pady=(0, 14))
        footer.grid_columnconfigure(0, weight=1)

        self.stats_label = ctk.CTkLabel(
            footer,
            text="0 models selected · 0 MB",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=MUTED,
            anchor="w",
        )
        self.stats_label.grid(row=0, column=0, sticky="w", pady=(0, 8))

        install_btn = ctk.CTkButton(
            footer,
            text="Install  ↓",
            width=220,
            height=48,
            corner_radius=24,
            font=ctk.CTkFont(size=15, weight="bold"),
            fg_color=ACCENT,
            hover_color=ACCENT_DIM,
            command=self._start_install,
        )
        install_btn.grid(row=1, column=0, sticky="ew")

        return frame

    def _make_model_row(self, parent, m: Model, var: ctk.BooleanVar) -> tuple:
        row = ctk.CTkFrame(parent, fg_color=SURFACE_2, corner_radius=10)
        row.grid_columnconfigure(1, weight=1)

        check = ctk.CTkCheckBox(
            row,
            text="",
            variable=var,
            width=28,
            corner_radius=6,
            fg_color=ACCENT,
            hover_color=ACCENT_DIM,
            border_color="#3a4452",
            command=self._update_stats,
        )
        check.grid(row=0, column=0, rowspan=2, padx=(12, 8), pady=8)

        name = ctk.CTkLabel(
            row,
            text=m.name,
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=TEXT,
            anchor="w",
        )
        name.grid(row=0, column=1, sticky="sw", pady=(8, 0))

        desc = ctk.CTkLabel(
            row,
            text=f"{m.tag} · {m.desc}",
            font=ctk.CTkFont(size=11),
            text_color=MUTED,
            anchor="w",
        )
        desc.grid(row=1, column=1, sticky="nw", pady=(0, 8))

        badge = ctk.CTkLabel(
            row,
            text=fmt_size(m.size_gb),
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=size_color(m.size_gb),
            fg_color="transparent",
            corner_radius=8,
            padx=8,
            pady=2,
            width=72,
        )
        badge.grid(row=0, column=1, rowspan=2, sticky="e", padx=(8, 12))

        return row, check, name, desc, badge

    # ------------------------------------------------------- config actions

    def _visible_models(self) -> list[Model]:
        q = self.search_var.get().strip().lower()
        cat = self.category_var.get()
        out = []
        for m in MODELS:
            if cat != "All" and m.category != cat:
                continue
            if q and q not in f"{m.name} {m.tag} {m.desc}".lower():
                continue
            out.append(m)
        return out

    def _refresh_model_list(self) -> None:
        if not hasattr(self, "row_widgets"):
            return
        visible = {m.tag for m in self._visible_models()}
        for tag, (row, *_rest) in self.row_widgets.items():
            if tag in visible:
                row.grid()
            else:
                row.grid_remove()
        total = len(MODELS)
        shown = len(visible)
        self.count_label.configure(text=f"Showing {shown} of {total} models")

    def _select_all(self) -> None:
        visible_tags = {m.tag for m in self._visible_models()}
        for tag, var in self.model_vars.items():
            if tag in visible_tags:
                var.set(True)
        self._update_stats()

    def _select_none(self) -> None:
        for var in self.model_vars.values():
            var.set(False)
        self._update_stats()

    def _selected_models(self) -> list[Model]:
        return [m for m in MODELS if self.model_vars[m.tag].get()]

    def _update_stats(self) -> None:
        selected = self._selected_models()
        total_gb = sum(m.size_gb for m in selected)
        free_gb = free_disk_gb()
        self.disk_label.configure(text=f"Free disk space: {fmt_size(free_gb)}")

        if not selected:
            self.stats_label.configure(text="No models selected yet", text_color=MUTED)
            return
        text = f"{len(selected)} model{'s' if len(selected) != 1 else ''} selected · {fmt_size(total_gb)} download"
        color = RED if total_gb > free_gb else ACCENT
        if total_gb > free_gb:
            text += f"  ⚠ exceeds free space ({fmt_size(free_gb)})"
        self.stats_label.configure(text=text, text_color=color)

    # ----------------------------------------------------------- state 3 UI

    def _build_progress(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self._container, fg_color=BG)
        frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            frame,
            text="Install",
            font=ctk.CTkFont(family="Segoe UI", size=36, weight="bold"),
            text_color=TEXT,
        ).grid(row=0, column=0, pady=(26, 0))
        ctk.CTkLabel(
            frame,
            text="Ollama",
            font=ctk.CTkFont(family="Segoe UI", size=36, weight="bold"),
            text_color=ACCENT,
        ).grid(row=1, column=0, pady=(0, 16))

        # --- step stepper
        stepper = ctk.CTkFrame(frame, fg_color="transparent")
        stepper.grid(row=2, column=0, pady=(0, 14))
        self.step_labels: list[ctk.CTkLabel] = []
        for i, label in enumerate(PHASE_STEPS):
            pill = ctk.CTkLabel(
                stepper,
                text=f"  {i + 1}. {label}  ",
                font=ctk.CTkFont(size=12, weight="bold"),
                fg_color=SURFACE,
                text_color=MUTED,
                corner_radius=14,
                padx=4,
                pady=4,
            )
            pill.grid(row=0, column=i, padx=5)
            self.step_labels.append(pill)
            if i < len(PHASE_STEPS) - 1:
                ctk.CTkLabel(
                    stepper, text="—", font=ctk.CTkFont(size=12), text_color="#2a323d"
                ).grid(row=0, column=i * 2 + 1)

        # --- status + bar
        self.status_label = ctk.CTkLabel(
            frame,
            text="Preparing installation…",
            font=ctk.CTkFont(size=13),
            text_color=MUTED,
            wraplength=620,
            justify="center",
        )
        self.status_label.grid(row=3, column=0, padx=40, pady=(4, 14))

        bar_wrap = ctk.CTkFrame(frame, fg_color="transparent")
        bar_wrap.grid(row=4, column=0, pady=(0, 6))
        bar_wrap.grid_columnconfigure(0, weight=1)

        self.progress = ctk.CTkProgressBar(
            bar_wrap,
            width=520,
            height=14,
            corner_radius=7,
            progress_color=ACCENT,
            fg_color=SURFACE,
        )
        self.progress.grid(row=0, column=0, sticky="ew")
        self.progress.set(0)

        self.percent_label = ctk.CTkLabel(
            bar_wrap, text="0%", font=ctk.CTkFont(size=12, weight="bold"), text_color=ACCENT
        )
        self.percent_label.grid(row=1, column=0, pady=(6, 0))

        # --- live log
        log_card = self._card(frame, corner_radius=14)
        log_card.grid(row=5, column=0, sticky="ew", padx=48, pady=(12, 8))
        log_card.grid_columnconfigure(0, weight=1)
        log_card.grid_rowconfigure(0, weight=1)

        self.log = ctk.CTkTextbox(
            log_card,
            height=150,
            fg_color="#0b0d10",
            text_color="#9fe8cf",
            font=ctk.CTkFont(family="Consolas", size=11),
            corner_radius=12,
            border_width=0,
            wrap="word",
        )
        self.log.grid(row=0, column=0, sticky="ew", padx=6, pady=6)
        self.log.configure(state="disabled")

        # --- actions
        actions = ctk.CTkFrame(frame, fg_color="transparent")
        actions.grid(row=6, column=0, pady=(8, 16))

        self.cancel_btn = ctk.CTkButton(
            actions,
            text="Cancel",
            width=140,
            height=40,
            corner_radius=20,
            fg_color=SURFACE,
            hover_color="#7f1d1d",
            text_color=MUTED,
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self._cancel_install,
        )
        self.cancel_btn.grid(row=0, column=0, padx=6)

        self.done_btn = ctk.CTkButton(
            actions,
            text="Done  ✓",
            width=140,
            height=40,
            corner_radius=20,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=ACCENT,
            hover_color=ACCENT_DIM,
            state="disabled",
            command=self._on_done,
        )
        self.done_btn.grid(row=0, column=1, padx=6)

        return frame

    # ---------------------------------------------------------------- actions

    def _start_install(self) -> None:
        selected = self._selected_models()
        if not selected:
            self._flash_no_models()
            return

        self.show("progress")
        self.progress.set(0)
        self.percent_label.configure(text="0%", text_color=ACCENT)
        self.progress.configure(progress_color=ACCENT)
        self.status_label.configure(text="Starting installation…", text_color=MUTED)
        self.done_btn.configure(state="disabled")
        self.cancel_btn.configure(state="normal", text="Cancel")
        self._set_step(-1)
        self._set_log("")

        config = InstallConfig(
            version=self.version_var.get(),
            models=[(m.tag, m.name) for m in selected],
        )
        self._installer = Installer(config, self._on_progress)
        self._installer.start()

    def _flash_no_models(self) -> None:
        for child in self.frames["config"].winfo_children():
            if isinstance(child, ctk.CTkFrame):
                for sub in child.winfo_children():
                    if isinstance(sub, ctk.CTkButton) and "Install" in str(sub.cget("text")):
                        original = "Install  ↓"
                        sub.configure(text="Select at least one model", state="disabled")
                        self.after(1600, lambda b=sub: b.configure(text=original, state="normal"))
                        return

    def _set_step(self, active: int, done_upto: Optional[int] = None) -> None:
        for i, pill in enumerate(self.step_labels):
            if done_upto is not None and i < done_upto:
                pill.configure(text=f"  ✓ {PHASE_STEPS[i]}  ", fg_color=ACCENT_BG2, text_color=ACCENT)
            elif i == active:
                pill.configure(text=f"  ● {PHASE_STEPS[i]}  ", fg_color=ACCENT_BG, text_color=ACCENT)
            else:
                pill.configure(text=f"  {i + 1}. {PHASE_STEPS[i]}  ", fg_color=SURFACE, text_color=MUTED)

    def _set_log(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.insert("end", text)
        self.log.configure(state="disabled")

    def _append_log(self, line: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", line + "\n")
        lines = int(self.log.index("end-1c").split(".")[0])
        if lines > 200:
            self.log.delete("1.0", f"{lines - 200}.0")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _on_progress(self, message: str, percent: Optional[float], phase: str) -> None:
        """Called from the worker thread — marshal to the Tk main loop."""
        self.after(0, lambda: self._apply_progress(message, percent, phase))

    _PHASE_INDEX = {"install": 0, "service": 1, "models": 2}

    def _apply_progress(self, message: str, percent: Optional[float], phase: str) -> None:
        self.status_label.configure(text=message)

        if phase in self._PHASE_INDEX:
            idx = self._PHASE_INDEX[phase]
            self._set_step(idx, done_upto=idx)

        if percent is None:
            # Terminal state.
            self.done_btn.configure(state="normal")
            self.cancel_btn.configure(state="disabled")
            if phase == "error":
                self.progress.configure(progress_color=RED)
                self.percent_label.configure(text_color=RED)
                self._set_step(-1)
            elif phase == "cancelled":
                self.progress.configure(progress_color=AMBER)
                self.percent_label.configure(text_color=AMBER)
            elif phase == "done":
                self._set_step(-1, done_upto=len(PHASE_STEPS))
            self._append_log(message)
            return

        clamped = max(0.0, min(1.0, percent / 100.0))
        self.progress.set(clamped)
        self.percent_label.configure(text=f"{percent:.0f}%")

        # Log only meaningful lines (skip noisy duplicate stream lines).
        if message != self._last_logged:
            self._append_log(message)
            self._last_logged = message

        if percent >= 100.0:
            self.done_btn.configure(state="normal")
            self.cancel_btn.configure(state="disabled")

    def _cancel_install(self) -> None:
        if self._installer:
            self._installer.cancel()
        self.cancel_btn.configure(state="disabled", text="Cancelling…")

    def _on_done(self) -> None:
        self.progress.configure(progress_color=ACCENT)
        self.percent_label.configure(text_color=ACCENT)
        self.show("config")


def main() -> None:
    app = InstallOllamaApp()
    app.mainloop()


if __name__ == "__main__":
    main()
